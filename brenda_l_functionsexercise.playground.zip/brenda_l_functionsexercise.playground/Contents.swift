enum makingacar0: String {
case car = "Mercedes"
case wheel = "chrome coated"
case engine = "inline"
case color = "black"
}
class makingacar{
    var car:Int = 1
    var wheel:Int = 1
    var engine:Int = 1
}
    func inventory(wheel:Int, engine: Int, car:Int)-> Int{
        return  wheel + engine + car
    }


var totall = makingacar()
var shoppingcart = totall.inventory (wheel: 1, engine: 1, car: 1)
var totalcart = totall.wheel + totall.engine + totall.car
print("you have \(totalcart) items in your shopping cart")
